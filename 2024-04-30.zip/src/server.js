import express from "express";

const app = express();
const PORT = 8000;

app.set("view engine", "ejs");
app.set("views", process.cwd() + "/src/client/html");

app.use("/css", express.static("src/client/css"));
app.use("/js", express.static("src/client/js"));
app.use("/file", express.static("src/client/file"));

app.get("/", (req, res) => {
  res.render("main");
});

app.get("/introduce", (req, res) => {
  res.render("introduce");
});

app.listen(PORT, () => {
  console.info(`서버가 열렸다. http://localhost:${PORT}`);
});
